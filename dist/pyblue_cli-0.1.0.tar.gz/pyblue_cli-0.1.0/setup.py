from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pyblue-cli",
    version="0.1.0",
    author="Tomi",
    author_email="tu@email.com",
    description="Blue Team Automation - Seguridad Defensiva con IA",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/tu-usuario/pyblue-cli",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "typer>=0.12.0",
        "rich>=13.7.0",
        "questionary>=2.0.1",
        "requests>=2.31.0",
    ],
    entry_points={
        "console_scripts": [
            "pyblue-cli=cli.main:app",
        ],
    },
)