# PyBlue-CLI

Blue Team Automation - Seguridad Defensiva con IA

## Instalación

```bash
pip install pyblue-cli